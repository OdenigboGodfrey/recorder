<?php

namespace App\Utilities;

trait ControllerTraits
{
    /**
     * @var
     */
    protected $path;

    /**
     * @var
     */
    protected $entity;
}